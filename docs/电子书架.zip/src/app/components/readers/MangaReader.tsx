import { useState } from "react";
import { ChevronLeft, ChevronRight, RotateCcw, ZoomIn } from "lucide-react";
import { mangaPages } from "./readerData";
import { Book } from "../bookData";

interface MangaReaderProps {
  book: Book;
}

export function MangaReader({ book }: MangaReaderProps) {
  const [page, setPage] = useState(0);
  const [direction, setDirection] = useState<"rtl" | "ltr">("rtl");
  const [zoom, setZoom] = useState(false);

  const current = mangaPages[page];
  const prev = () => setPage(v => Math.max(0, v - 1));
  const next = () => setPage(v => Math.min(mangaPages.length - 1, v + 1));

  return (
    <div
      className="flex flex-col h-full select-none"
      style={{ background: "#0d0d0d" }}
    >
      {/* Toolbar */}
      <div
        className="flex items-center justify-between px-4 py-2 flex-shrink-0"
        style={{ background: "#1a1a1a", borderBottom: "1px solid rgba(255,255,255,0.08)" }}
      >
        <div className="flex items-center gap-2">
          <span className="text-xs" style={{ color: "#888", fontFamily: "Inter, sans-serif" }}>
            {page + 1} / {mangaPages.length}
          </span>
          <div className="w-px h-3 mx-1" style={{ background: "rgba(255,255,255,0.15)" }} />
          <button
            onClick={() => setDirection(v => v === "rtl" ? "ltr" : "rtl")}
            className="flex items-center gap-1.5 px-2 py-1 rounded text-xs transition-colors hover:bg-white/10"
            style={{ color: "#888", fontFamily: "Inter, sans-serif" }}
          >
            <RotateCcw size={12} />
            {direction === "rtl" ? "从右到左" : "从左到右"}
          </button>
        </div>

        <p className="text-xs truncate" style={{ color: "#666", fontFamily: "Inter, sans-serif" }}>
          {book.title}
        </p>

        <button
          onClick={() => setZoom(v => !v)}
          className="p-1.5 rounded transition-colors hover:bg-white/10"
          style={{ color: zoom ? "#c17f3a" : "#888" }}
        >
          <ZoomIn size={15} />
        </button>
      </div>

      {/* Page viewer */}
      <div
        className="flex-1 flex items-center justify-center relative overflow-hidden"
        onClick={e => {
          const rect = (e.target as HTMLElement).closest(".manga-area")?.getBoundingClientRect();
          if (!rect) return;
          const x = e.clientX - rect.left;
          if (direction === "rtl") {
            x < rect.width / 2 ? next() : prev();
          } else {
            x > rect.width / 2 ? next() : prev();
          }
        }}
      >
        <div
          className="manga-area relative h-full flex items-center justify-center cursor-pointer"
          style={{ width: "100%" }}
        >
          <img
            src={current.image}
            alt={current.alt}
            className="max-h-full transition-all duration-300"
            style={{
              maxWidth: zoom ? "100%" : "80%",
              objectFit: "contain",
              boxShadow: "0 0 60px rgba(0,0,0,0.8)",
            }}
          />

          {/* Tap zone hints on hover */}
          <div
            className="absolute left-0 top-0 bottom-0 w-1/2 flex items-center pl-4 opacity-0 hover:opacity-100 transition-opacity"
          >
            <div
              className="p-2 rounded-full"
              style={{ background: "rgba(255,255,255,0.1)" }}
            >
              {direction === "rtl" ? <ChevronRight size={20} style={{ color: "white" }} /> : <ChevronLeft size={20} style={{ color: "white" }} />}
            </div>
          </div>
          <div
            className="absolute right-0 top-0 bottom-0 w-1/2 flex items-center justify-end pr-4 opacity-0 hover:opacity-100 transition-opacity"
          >
            <div
              className="p-2 rounded-full"
              style={{ background: "rgba(255,255,255,0.1)" }}
            >
              {direction === "rtl" ? <ChevronLeft size={20} style={{ color: "white" }} /> : <ChevronRight size={20} style={{ color: "white" }} />}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom progress strip */}
      <div
        className="flex items-center gap-3 px-4 py-3 flex-shrink-0"
        style={{ background: "#1a1a1a", borderTop: "1px solid rgba(255,255,255,0.08)" }}
      >
        <button
          onClick={prev}
          disabled={page === 0}
          className="p-1.5 rounded transition-colors hover:bg-white/10 disabled:opacity-30"
          style={{ color: "white" }}
        >
          <ChevronLeft size={16} />
        </button>

        <div className="flex-1 flex gap-1">
          {mangaPages.map((_, i) => (
            <button
              key={i}
              onClick={() => setPage(i)}
              className="flex-1 h-1.5 rounded-full transition-all"
              style={{ background: i === page ? "#c17f3a" : "rgba(255,255,255,0.2)" }}
            />
          ))}
        </div>

        <button
          onClick={next}
          disabled={page === mangaPages.length - 1}
          className="p-1.5 rounded transition-colors hover:bg-white/10 disabled:opacity-30"
          style={{ color: "white" }}
        >
          <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
}
