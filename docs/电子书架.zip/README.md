
  # 电子书架

  This is a code bundle for 电子书架. The original project is available at https://www.figma.com/design/5tHNLrX6xGCOmDlwvWljkR/%E7%94%B5%E5%AD%90%E4%B9%A6%E6%9E%B6.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  